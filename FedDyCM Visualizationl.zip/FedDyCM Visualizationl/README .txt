1. Connect to the Internet.
2. Open the FedDyCM.html file in the network data folder.
3. Wait for 1-2 minutes, and the evolution of community division will be presented.

Note: Do not change the path within the question folder.